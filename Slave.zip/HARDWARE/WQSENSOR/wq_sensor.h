#ifndef __WQ_SENSOR_H
#define __WQ_SENSOR_H

#include "sys.h"

#define WQ_REG_COUNT             7

#define WQ_REG_PH                0
#define WQ_REG_TEMPERATURE       1
#define WQ_REG_TURBIDITY         2
#define WQ_REG_CONDUCTIVITY      3
#define WQ_REG_SENSOR_STATUS     4
#define WQ_REG_ALARM_STATUS      5
#define WQ_REG_SEQUENCE          6

#define WQ_ALARM_PH_LOW          (1U << 0)
#define WQ_ALARM_PH_HIGH         (1U << 1)
#define WQ_ALARM_TURB_HIGH       (1U << 2)
#define WQ_ALARM_COND_HIGH       (1U << 3)

typedef struct
{
    u16 ph_x100;            /* 712 -> 7.12 */
    s16 temperature_x100;   /* 2534 -> 25.34 C */
    u16 turbidity_x100;     /* 320 -> 3.20 NTU */
    u16 conductivity;       /* us/cm */
    u16 sensor_status;
    u16 alarm_status;
    u16 sequence;
} wq_sample_t;

extern wq_sample_t g_wq_sample;

void wq_sensor_init(void);
void wq_sensor_task(void);
void wq_get_regs(u16 *regs, u16 start_addr, u16 quantity);
void wq_generate_regs(unsigned short *regs);

#endif
