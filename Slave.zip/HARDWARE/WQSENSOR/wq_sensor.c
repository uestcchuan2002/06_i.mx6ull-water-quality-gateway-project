#include "wq_sensor.h"

#define WQ_UPDATE_PERIOD_MS      1000U

#define WQ_PH_LOW_LIMIT_X100      650U
#define WQ_PH_HIGH_LIMIT_X100     850U
#define WQ_TURB_HIGH_LIMIT_X100  5000U
#define WQ_COND_HIGH_LIMIT       1500U

wq_sample_t g_wq_sample;
static u32 g_last_update_tick = 0;

static u16 wq_calc_alarm_status(const wq_sample_t *sample)
{
    u16 alarm = 0;

    if (sample->ph_x100 < WQ_PH_LOW_LIMIT_X100) {
        alarm |= WQ_ALARM_PH_LOW;
    }
    if (sample->ph_x100 > WQ_PH_HIGH_LIMIT_X100) {
        alarm |= WQ_ALARM_PH_HIGH;
    }
    if (sample->turbidity_x100 > WQ_TURB_HIGH_LIMIT_X100) {
        alarm |= WQ_ALARM_TURB_HIGH;
    }
    if (sample->conductivity > WQ_COND_HIGH_LIMIT) {
        alarm |= WQ_ALARM_COND_HIGH;
    }

    return alarm;
}

static void wq_sample_to_regs(const wq_sample_t *sample, u16 *regs)
{
    regs[WQ_REG_PH]            = sample->ph_x100;
    regs[WQ_REG_TEMPERATURE]   = (u16)sample->temperature_x100;
    regs[WQ_REG_TURBIDITY]     = sample->turbidity_x100;
    regs[WQ_REG_CONDUCTIVITY]  = sample->conductivity;
    regs[WQ_REG_SENSOR_STATUS] = sample->sensor_status;
    regs[WQ_REG_ALARM_STATUS]  = sample->alarm_status;
    regs[WQ_REG_SEQUENCE]      = sample->sequence;
}

static void wq_refresh_sample(void)
{
    u16 seq;

    seq = (u16)(g_wq_sample.sequence + 1U);

    g_wq_sample.ph_x100          = (u16)(700U + (seq % 40U));
    g_wq_sample.temperature_x100 = (s16)(2500 + (s16)(seq % 50U));
    g_wq_sample.turbidity_x100   = (u16)(300U + (seq % 30U));
    g_wq_sample.conductivity     = (u16)(800U + (seq % 40U));
    g_wq_sample.sensor_status    = 0U;
    g_wq_sample.sequence         = seq;
    g_wq_sample.alarm_status     = wq_calc_alarm_status(&g_wq_sample);
}

void wq_sensor_init(void)
{
    g_wq_sample.sequence = 0U;
    wq_refresh_sample();
    g_last_update_tick = HAL_GetTick();
}

void wq_sensor_task(void)
{
    u32 now = HAL_GetTick();

    if ((u32)(now - g_last_update_tick) >= WQ_UPDATE_PERIOD_MS) {
        g_last_update_tick = now;
        wq_refresh_sample();
    }
}

void wq_get_regs(u16 *regs, u16 start_addr, u16 quantity)
{
    u16 all_regs[WQ_REG_COUNT];
    u16 i;

    if (regs == 0 ||
        start_addr >= WQ_REG_COUNT ||
        quantity == 0U ||
        (u32)start_addr + (u32)quantity > WQ_REG_COUNT) {
        return;
    }

    wq_sample_to_regs(&g_wq_sample, all_regs);

    for (i = 0; i < quantity; i++) {
        regs[i] = all_regs[start_addr + i];
    }
}

void wq_generate_regs(unsigned short *regs)
{
    if (regs == 0) {
        return;
    }

    wq_sensor_task();
    wq_get_regs((u16 *)regs, 0U, WQ_REG_COUNT);
}
