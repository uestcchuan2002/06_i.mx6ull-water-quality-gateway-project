#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "usart3.h"
#include "wq_sensor.h"
#include "led.h"
#include "lcd.h"
#include "timer.h"
#include "stdio.h"

char dispaly_buf[32];

int main(void)
{
    HAL_Init();
    Stm32_Clock_Init(336,8,2,7);
    delay_init(168);
    uart_init(115200);
    usart3_init(9600);
    LED_Init();
	LCD_Init();
	TIM3_Init(8400, 10000);
	
    printf("\r\n=== Water Quality Modbus Slave ===\r\n");
    printf("  UART3: PB10(TX) PB11(RX) 9600-8N1\r\n");
    printf("  DMA + IDLE interrupt mode\r\n");
    printf("  Slave Addr: 0x01\r\n");
    printf("  Registers: pH temp turb cond status alarm seq\r\n");
    printf("  Waiting for Modbus master...\r\n");
	
	POINT_COLOR = RED;
	LCD_ShowString(10, 10, 300, 40, 32, (u8*)"Water Quality");
	LCD_ShowString(10, 50, 300, 40, 32, (u8*)"DMA + IDLE interrupt");
	POINT_COLOR = BLUE;
	LCD_ShowString(10, 90, 300, 40, 32, (u8*)"pH:");
	LCD_ShowString(10, 130, 300, 40, 32, (u8*)"temp:");
	LCD_ShowString(10, 170, 300, 40, 32, (u8*)"turb:");
	LCD_ShowString(10, 210, 300, 40, 32, (u8*)"cond:");
	LCD_ShowString(10, 250, 300, 40, 32, (u8*)"status:");
	LCD_ShowString(10, 290, 300, 40, 32, (u8*)"alarm:");
	LCD_ShowString(10, 330, 300, 40, 32, (u8*)"seq:");
	
    while(1) {
		if (display_flag == 1) {
			display_flag = 0;
			sprintf(dispaly_buf, "%d", g_wq_sample.ph_x100);
			LCD_ShowString(230, 90, 300, 40, 32, (u8*)dispaly_buf);
			sprintf(dispaly_buf, "%d", g_wq_sample.temperature_x100);
			LCD_ShowString(230, 130, 300, 40, 32, (u8*)dispaly_buf);
			sprintf(dispaly_buf, "%d", g_wq_sample.turbidity_x100);
			LCD_ShowString(230, 170, 300, 40, 32, (u8*)dispaly_buf);
			sprintf(dispaly_buf, "%d", g_wq_sample.conductivity);
			LCD_ShowString(230, 210, 300, 40, 32, (u8*)dispaly_buf);
			sprintf(dispaly_buf, "%d", g_wq_sample.sensor_status);
			LCD_ShowString(230, 250, 300, 40, 32, (u8*)dispaly_buf);
			sprintf(dispaly_buf, "%d", g_wq_sample.alarm_status);
			LCD_ShowString(230, 290, 300, 40, 32, (u8*)dispaly_buf);
			sprintf(dispaly_buf, "%d", g_wq_sample.sequence);
			LCD_ShowString(230, 330, 300, 40, 32, (u8*)dispaly_buf);
		}
		
        modbus_slave_process();
        if (frame_ready == 2) {
            LED0 = !LED0;
            frame_ready = 0;
        }
    }
}
