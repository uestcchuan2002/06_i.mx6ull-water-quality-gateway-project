#include "usart3.h"
#include "delay.h"

UART_HandleTypeDef UART3_Handler;
DMA_HandleTypeDef  UART3_RxDMA_Handler;

u8  dma_rx_buf[DMA_RX_BUF_SIZE];
volatile u16 dma_rx_len  = 0;
volatile u8  frame_ready = 0;

void usart3_init(u32 bound)
{
    UART3_Handler.Instance          = USART3;
    UART3_Handler.Init.BaudRate     = bound;
    UART3_Handler.Init.WordLength   = UART_WORDLENGTH_8B;
    UART3_Handler.Init.StopBits     = UART_STOPBITS_1;
    UART3_Handler.Init.Parity       = UART_PARITY_NONE;
    UART3_Handler.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    UART3_Handler.Init.Mode         = UART_MODE_TX_RX;
    HAL_UART_Init(&UART3_Handler);

    __HAL_RCC_DMA1_CLK_ENABLE();

    UART3_RxDMA_Handler.Instance                 = DMA1_Stream1;
    UART3_RxDMA_Handler.Init.Channel             = DMA_CHANNEL_4;
    UART3_RxDMA_Handler.Init.Direction           = DMA_PERIPH_TO_MEMORY;
    UART3_RxDMA_Handler.Init.PeriphInc           = DMA_PINC_DISABLE;
    UART3_RxDMA_Handler.Init.MemInc              = DMA_MINC_ENABLE;
    UART3_RxDMA_Handler.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
    UART3_RxDMA_Handler.Init.MemDataAlignment    = DMA_MDATAALIGN_BYTE;
    UART3_RxDMA_Handler.Init.Mode                = DMA_NORMAL;
    UART3_RxDMA_Handler.Init.Priority            = DMA_PRIORITY_HIGH;
    UART3_RxDMA_Handler.Init.FIFOMode            = DMA_FIFOMODE_DISABLE;
    HAL_DMA_Init(&UART3_RxDMA_Handler);

    __HAL_LINKDMA(&UART3_Handler, hdmarx, UART3_RxDMA_Handler);

    HAL_NVIC_EnableIRQ(DMA1_Stream1_IRQn);
    HAL_NVIC_SetPriority(DMA1_Stream1_IRQn, 3, 3);

    HAL_NVIC_EnableIRQ(USART3_IRQn);
    HAL_NVIC_SetPriority(USART3_IRQn, 3, 3);

    HAL_UART_Receive_DMA(&UART3_Handler, dma_rx_buf, DMA_RX_BUF_SIZE);
    __HAL_UART_ENABLE_IT(&UART3_Handler, UART_IT_IDLE);
}

void DMA1_Stream1_IRQHandler(void)
{
    HAL_DMA_IRQHandler(UART3_Handler.hdmarx);
}

void USART3_IRQHandler(void)
{
    if (__HAL_UART_GET_FLAG(&UART3_Handler, UART_FLAG_IDLE) != RESET) {
        u16 ndtr;

        __HAL_UART_CLEAR_IDLEFLAG(&UART3_Handler);

        ndtr = __HAL_DMA_GET_COUNTER(UART3_Handler.hdmarx);
        dma_rx_len = DMA_RX_BUF_SIZE - ndtr;

        HAL_UART_AbortReceive(&UART3_Handler);
        frame_ready = 1;
        return;
    }

    if (__HAL_UART_GET_FLAG(&UART3_Handler, UART_FLAG_ORE)) {
        (void)(USART3->DR & 0xFF);
        __HAL_UART_CLEAR_FLAG(&UART3_Handler, UART_FLAG_ORE);
    }
}

static unsigned short modbus_crc16(const unsigned char *buf, int len)
{
    unsigned short crc = 0xFFFF;
    int i, j;

    for (i = 0; i < len; i++) {
        crc ^= (unsigned short)buf[i];
        for (j = 0; j < 8; j++) {
            if (crc & 0x0001)
                crc = (unsigned short)((crc >> 1) ^ 0xA001);
            else
                crc >>= 1;
        }
    }
    return crc;
}

static void modbus_build_response(const unsigned short *regs, int reg_count,
                                   unsigned char *buf, int *out_len)
{
    int byte_count = reg_count * 2;
    unsigned short crc;
    int i;

    buf[0] = MODBUS_SLAVE_ADDR;
    buf[1] = MODBUS_FUNC_READ;
    buf[2] = (unsigned char)byte_count;

    for (i = 0; i < reg_count; i++) {
        buf[3 + i * 2] = (unsigned char)(regs[i] >> 8);
        buf[4 + i * 2] = (unsigned char)(regs[i] & 0xFF);
    }

    crc = modbus_crc16(buf, 3 + byte_count);
    buf[3 + byte_count] = (unsigned char)(crc & 0xFF);
    buf[4 + byte_count] = (unsigned char)(crc >> 8);
    *out_len = 5 + byte_count;
}

static void uart3_flush_rx(void)
{
    u32 timeout = 0;

    while (__HAL_UART_GET_FLAG(&UART3_Handler, UART_FLAG_RXNE)) {
        (void)(USART3->DR & 0xFF);
        if (++timeout > 10000) break;
    }
}

void modbus_slave_process(void)
{
    unsigned short regs[MODBUS_REG_COUNT];
    unsigned char tx_buf[MODBUS_RESP_LEN];
    unsigned short start_addr, quantity, crc_received, crc_calc;
    int tx_len;
    u8 func;
    extern void wq_generate_regs(unsigned short *regs);

    if (!frame_ready)
        return;

    frame_ready = 0;

    if (dma_rx_len < 8) {
        goto restart;
    }

    crc_calc     = modbus_crc16(dma_rx_buf, 6);
    crc_received = (unsigned short)dma_rx_buf[6]
                 | ((unsigned short)dma_rx_buf[7] << 8);

    if (crc_calc != crc_received)
        goto restart;

    if (dma_rx_buf[0] != MODBUS_SLAVE_ADDR)
        goto restart;

    func       = dma_rx_buf[1];
    start_addr = ((unsigned short)dma_rx_buf[2] << 8) | (unsigned short)dma_rx_buf[3];
    quantity   = ((unsigned short)dma_rx_buf[4] << 8) | (unsigned short)dma_rx_buf[5];

    if (func != MODBUS_FUNC_READ)
        goto restart;

    if (start_addr != 0 || quantity != MODBUS_REG_COUNT)
        goto restart;

    wq_generate_regs(regs);
    modbus_build_response(regs, MODBUS_REG_COUNT, tx_buf, &tx_len);
    HAL_UART_Transmit(&UART3_Handler, tx_buf, (uint16_t)tx_len, 100);

    delay_us(500);
    uart3_flush_rx();

    frame_ready = 2;

restart:
    dma_rx_len = 0;
    HAL_UART_Receive_DMA(&UART3_Handler, dma_rx_buf, DMA_RX_BUF_SIZE);
    __HAL_UART_ENABLE_IT(&UART3_Handler, UART_IT_IDLE);
}
