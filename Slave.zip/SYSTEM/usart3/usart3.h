#ifndef __USART3_H
#define __USART3_H

#include "sys.h"

#define MODBUS_SLAVE_ADDR      0x01
#define MODBUS_FUNC_READ       0x03
#define MODBUS_REG_COUNT        7
#define MODBUS_RESP_LEN        19
#define DMA_RX_BUF_SIZE        64

extern UART_HandleTypeDef UART3_Handler;
extern DMA_HandleTypeDef  UART3_RxDMA_Handler;
extern u8  dma_rx_buf[DMA_RX_BUF_SIZE];
extern volatile u16 dma_rx_len;
extern volatile u8  frame_ready;

void usart3_init(u32 bound);
void modbus_slave_process(void);

#endif
